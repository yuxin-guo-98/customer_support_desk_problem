﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace customersupport.Model
{
    public class UserAccounts
    {
        public string AdminAccount { get; set; }
        public string HashedPassword { get; set; }
    }
}
